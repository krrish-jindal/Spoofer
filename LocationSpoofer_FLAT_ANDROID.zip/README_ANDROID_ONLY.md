# LocationSpoofer — Android-only build

This is a native Android mock-location app. It is NOT an AppMint WebView package.

## Build using only your Android phone
1. Create a GitHub repository in your browser.
2. Upload the contents of this ZIP so that `LocationSpoofer/settings.gradle.kts` and `LocationSpoofer/app/...` are in the repository.
3. Open **Actions** → **Build APK** → **Run workflow**.
4. When it finishes, open the workflow run → **Artifacts** → `LocationSpoofer-debug` and download the ZIP.
5. Extract `app-debug.apk` and install it.
6. Android Settings → Developer options → **Select mock location app** → choose **Location Spoofer**.
7. Open the app, enter latitude/longitude, and press **Start mock location**.

## Important
Do not import this project into AppMint. AppMint's documented web bridge can read device location but does not expose an API to inject system mock GPS.

The app uses Android's standard mock-location/test-provider mechanism for normal testing. It does not attempt to bypass apps that detect mock locations.
