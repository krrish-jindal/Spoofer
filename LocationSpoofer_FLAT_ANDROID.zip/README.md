# Location Spoofer — Mock GPS build

IMPORTANT FIX:
The previous project did not declare ACCESS_MOCK_LOCATION, which is why Android showed:

Select application
Nothing

This build declares:
android.permission.ACCESS_MOCK_LOCATION

After installing this APK:

1. Settings -> Developer options
2. Select mock location app
3. Choose "Location Spoofer"
4. Open Location Spoofer
5. Search a place OR enter latitude/longitude
6. Press Start mock location

The app uses Android's test/mock location provider.

If "Location Spoofer" still does not appear:
- uninstall the previous version first
- install this new APK
- make sure Developer options is enabled
- restart Settings if the list was already open

The AppMint web-content build is separate. AppMint's HTML bridge cannot add
Android's mock-location provider by JavaScript alone. This native APK is the
version intended to appear in "Select mock location app".
