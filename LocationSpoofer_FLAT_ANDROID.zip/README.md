Native Android mock-location app. Build with the supplied GitHub Actions workflow.
