plugins {
    id("com.android.application") version "8.5.2"
}

android {
    namespace = "com.example.locationspoofer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.locationspoofer"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "3.0"
    }
}
