package com.example.locationspoofer;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static WebView web;
    private static final int REQ_PERMISSIONS = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
        }

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            }, REQ_PERMISSIONS);
        }

        web = findViewById(R.id.web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    public static void notifyNativeError(String message) {
        if (web == null) return;
        String safe = message.replace("\\", "\\\\").replace("'", "\\'");
        web.post(() -> web.evaluateJavascript(
            "window.__nativeError && window.__nativeError('" + safe + "')",
            null
        ));
    }

    public static void notifyNativeStatus(String message) {
        if (web == null) return;
        String safe = message.replace("\\", "\\\\").replace("'", "\\'");
        web.post(() -> web.evaluateJavascript(
            "window.__nativeStatus && window.__nativeStatus('" + safe + "')",
            null
        ));
    }

    private void startMockLocation(double latitude, double longitude) {
        try {
            Intent intent = new Intent(this, MockLocationService.class);
            intent.putExtra(MockLocationService.EXTRA_LAT, latitude);
            intent.putExtra(MockLocationService.EXTRA_LON, longitude);

            if (android.os.Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }

            // The selected mock-location app is required by Android. The
            // service reports a precise error if the fused mock API rejects it.
        } catch (SecurityException e) {
            notifyNativeError(
                "Select Location Spoofer in Developer options -> Select mock location app first."
            );
        } catch (Exception e) {
            notifyNativeError("Mock location failed: " + e.getMessage());
        }
    }

    private void stopMockLocation() {
        stopService(new Intent(this, MockLocationService.class));
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void startMockLocation(String lat, String lon) {
            try {
                double latitude = Double.parseDouble(lat);
                double longitude = Double.parseDouble(lon);

                if (latitude < -90 || latitude > 90 ||
                    longitude < -180 || longitude > 180) {
                    notifyNativeError("Latitude/longitude is out of range.");
                    return;
                }

                MainActivity.this.startMockLocation(latitude, longitude);
            } catch (Exception e) {
                notifyNativeError("Invalid latitude/longitude.");
            }
        }

        @JavascriptInterface
        public void stopMockLocation() {
            MainActivity.this.stopMockLocation();
        }

        @JavascriptInterface
        public void openDeveloperSettings() {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        }
    }
}
