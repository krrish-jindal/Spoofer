package com.example.locationspoofer;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private LocationManager locationManager;
    private static final String PROVIDER = LocationManager.GPS_PROVIDER;
    private static final int REQ_PERMISSIONS = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
        }

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            }, REQ_PERMISSIONS);
        }

        web = findViewById(R.id.web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    private void sendError(String message) {
        if (web != null) {
            String safe = message.replace("\\", "\\\\").replace("'", "\\'");
            runOnUiThread(() -> web.evaluateJavascript(
                "window.__nativeError && window.__nativeError('" + safe + "')", null));
        }
    }

    private void setMockLocation(double latitude, double longitude) {
        try {
            // The app must first be selected under Developer options ->
            // Select mock location app.
            try {
                locationManager.removeTestProvider(PROVIDER);
            } catch (Exception ignored) {}

            try {
                locationManager.addTestProvider(
                    PROVIDER,
                    false, false, false, false,
                    true, true, true,
                    android.location.Criteria.POWER_LOW,
                    android.location.Criteria.ACCURACY_FINE
                );
            } catch (IllegalArgumentException ignored) {
                // Provider may already be a test provider.
            }

            locationManager.setTestProviderEnabled(PROVIDER, true);

            Location location = new Location(PROVIDER);
            location.setLatitude(latitude);
            location.setLongitude(longitude);
            location.setAltitude(0.0);
            location.setAccuracy(1.0f);
            location.setBearing(0.0f);
            location.setSpeed(0.0f);
            location.setTime(System.currentTimeMillis());
            location.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());

            locationManager.setTestProviderLocation(PROVIDER, location);

            if (android.os.Build.VERSION.SDK_INT >= 26) {
                startForegroundService(new Intent(this, MockLocationService.class));
            } else {
                startService(new Intent(this, MockLocationService.class));
            }
        } catch (SecurityException e) {
            sendError("Select Location Spoofer in Developer options -> Select mock location app first.");
        } catch (Exception e) {
            sendError("Mock location failed: " + e.getMessage());
        }
    }

    private void stopMockLocation() {
        try { locationManager.setTestProviderEnabled(PROVIDER, false); } catch (Exception ignored) {}
        try { locationManager.removeTestProvider(PROVIDER); } catch (Exception ignored) {}
        stopService(new Intent(this, MockLocationService.class));
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void startMockLocation(String lat, String lon) {
            try {
                setMockLocation(Double.parseDouble(lat), Double.parseDouble(lon));
            } catch (Exception e) {
                sendError("Invalid latitude/longitude.");
            }
        }

        @JavascriptInterface
        public void stopMockLocation() {
            MainActivity.this.stopMockLocation();
        }

        @JavascriptInterface
        public void openDeveloperSettings() {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        }
    }
}
