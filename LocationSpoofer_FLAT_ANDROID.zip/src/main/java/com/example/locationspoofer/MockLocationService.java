package com.example.locationspoofer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class MockLocationService extends Service {
    private static final String CHANNEL_ID = "mock_location";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
            CHANNEL_ID, "Mock Location", NotificationManager.IMPORTANCE_LOW));

        Notification notification = new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Location Spoofer")
            .setContentText("Mock location is active")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build();

        startForeground(1001, notification);
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
