package com.example.locationspoofer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var locationManager: LocationManager
    private val provider = LocationManager.GPS_PROVIDER

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        locationManager = getSystemService(LocationManager::class.java)

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                10
            )
        }

        web = findViewById(R.id.web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun setMockLocation(latitude: Double, longitude: Double) {
        try {
            // The user must select this package as the mock-location app.
            // Android then grants the mock-location AppOp needed for test providers.
            if (locationManager.getProvider(provider) == null) {
                locationManager.addTestProvider(
                    provider,
                    false, false, false, false,
                    true, true, true,
                    0, 5
                )
            }

            locationManager.setTestProviderEnabled(provider, true)

            val location = Location(provider).apply {
                this.latitude = latitude
                this.longitude = longitude
                altitude = 0.0
                accuracy = 1.0f
                bearing = 0.0f
                speed = 0.0f
                time = System.currentTimeMillis()
                elapsedRealtimeNanos =
                    android.os.SystemClock.elapsedRealtimeNanos()
            }

            locationManager.setTestProviderLocation(provider, location)

            ContextCompat.startForegroundService(
                this,
                Intent(this, MockLocationService::class.java)
            )

        } catch (e: SecurityException) {
            runOnUiThread {
                web.evaluateJavascript(
                    "window.__nativeError && window.__nativeError(" +
                        "'Select Location Spoofer under Developer options → Select mock location app first.')",
                    null
                )
            }
        } catch (e: Exception) {
            runOnUiThread {
                web.evaluateJavascript(
                    "window.__nativeError && window.__nativeError(" +
                        "'Mock location failed: " +
                        e.message.orEmpty().replace("'", "\\'") +
                        "')",
                    null
                )
            }
        }
    }

    private fun stopMockLocation() {
        try {
            locationManager.setTestProviderEnabled(provider, false)
        } catch (_: Exception) {}

        try {
            locationManager.removeTestProvider(provider)
        } catch (_: Exception) {}

        stopService(Intent(this, MockLocationService::class.java))
    }

    inner class AndroidBridge {

        @JavascriptInterface
        fun startMockLocation(lat: String, lon: String) {
            val latitude = lat.toDoubleOrNull() ?: return
            val longitude = lon.toDoubleOrNull() ?: return
            setMockLocation(latitude, longitude)
        }

        @JavascriptInterface
        fun stopMockLocation() {
            stopMockLocation()
        }

        @JavascriptInterface
        fun openDeveloperSettings() {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
    }
}
