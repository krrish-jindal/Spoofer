plugins {
    id("com.android.application") version "8.5.2"
}

android {
    namespace = "com.example.locationspoofer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.locationspoofer"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "4.1"
    }
}


dependencies {
    implementation("com.google.android.gms:play-services-location:21.4.0")
}
