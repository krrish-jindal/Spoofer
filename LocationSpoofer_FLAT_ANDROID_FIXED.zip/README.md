# Location Spoofer

Android mock-location test app. Select **Location Spoofer** under Developer options > Select mock location app, then enter coordinates and start mock location.

This version uses Google Play services Fused Location Provider mock mode and repeatedly injects the selected location while the foreground service is running.
