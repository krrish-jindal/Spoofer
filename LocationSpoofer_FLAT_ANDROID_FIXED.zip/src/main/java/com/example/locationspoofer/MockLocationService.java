package com.example.locationspoofer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

/**
 * Keeps a mock location active through Google Play services' fused location
 * provider. This is intended for Android's Developer Options mock-location
 * testing workflow.
 */
public class MockLocationService extends Service {
    private static final String CHANNEL_ID = "mock_location";
    private static final int NOTIFICATION_ID = 1001;
    private static final long UPDATE_MS = 1000L;

    public static final String EXTRA_LAT = "latitude";
    public static final String EXTRA_LON = "longitude";

    private FusedLocationProviderClient fusedClient;
    private Handler handler;
    private Runnable updateRunnable;
    private double latitude;
    private double longitude;
    private boolean mockModeEnabled = false;

    @Override
    public void onCreate() {
        super.onCreate();

        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
            CHANNEL_ID,
            "Mock Location",
            NotificationManager.IMPORTANCE_LOW
        ));

        Notification notification = new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Location Spoofer")
            .setContentText("Mock location is active")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build();

        startForeground(NOTIFICATION_ID, notification);

        fusedClient = LocationServices.getFusedLocationProviderClient(this);
        handler = new Handler(Looper.getMainLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            latitude = intent.getDoubleExtra(EXTRA_LAT, latitude);
            longitude = intent.getDoubleExtra(EXTRA_LON, longitude);
        }

        enableMockModeAndStartUpdates();
        return START_STICKY;
    }

    private void enableMockModeAndStartUpdates() {
        fusedClient.setMockMode(true)
            .addOnSuccessListener(unused -> {
                mockModeEnabled = true;
                pushLocation();
                startRepeatingUpdates();
            })
            .addOnFailureListener(e -> {
                MainActivity.notifyNativeError(
                    "Fused mock mode failed: " + safeMessage(e)
                );
            });
    }

    private void startRepeatingUpdates() {
        if (updateRunnable != null) {
            handler.removeCallbacks(updateRunnable);
        }

        updateRunnable = new Runnable() {
            @Override
            public void run() {
                if (mockModeEnabled) {
                    pushLocation();
                    handler.postDelayed(this, UPDATE_MS);
                }
            }
        };

        handler.post(updateRunnable);
    }

    private void pushLocation() {
        Location location = new Location(LocationManager.GPS_PROVIDER);
        location.setLatitude(latitude);
        location.setLongitude(longitude);
        location.setAltitude(0.0);
        location.setAccuracy(1.0f);
        location.setBearing(0.0f);
        location.setSpeed(0.0f);
        location.setTime(System.currentTimeMillis());
        location.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());

        fusedClient.setMockLocation(location)
            .addOnSuccessListener(unused -> MainActivity.notifyNativeStatus(
                "Mock location ACTIVE: " + latitude + ", " + longitude
            ))
            .addOnFailureListener(e -> MainActivity.notifyNativeError(
                "Fused mock location failed: " + safeMessage(e)
            ));
    }

    private String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null ? e.getClass().getSimpleName() : message;
    }

    @Override
    public void onDestroy() {
        if (handler != null && updateRunnable != null) {
            handler.removeCallbacks(updateRunnable);
        }

        if (fusedClient != null && mockModeEnabled) {
            fusedClient.setMockMode(false);
        }

        mockModeEnabled = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
